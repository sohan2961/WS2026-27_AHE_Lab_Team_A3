
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity pwm_top is
    Port (
        clk    : in  std_logic;
        rst_n  : in  std_logic;
        sw     : in  std_logic_vector(3 downto 0);
        led    : out std_logic
    );
end pwm_top;

architecture Behavioral of pwm_top is

    signal duty_value : unsigned(3 downto 0);
    signal pwm_signal : std_logic;

    signal slow_clk : std_logic := '0';
    signal divider  : integer range 0 to 49999 := 0;

begin

    -- Divide the 100 MHz FPGA clock to 1 kHz
    process(clk)
    begin
        if rising_edge(clk) then
            if divider = 49999 then
                divider <= 0;
                slow_clk <= not slow_clk;
            else
                divider <= divider + 1;
            end if;
        end if;
    end process;

    duty_value <= unsigned(sw);

    PWM_UNIT : entity work.pwm_core
        generic map (
            G_WIDTH => 4
        )
        port map (
            clk     => slow_clk,
            rst_n   => rst_n,
            enable  => '1',
            duty    => duty_value,
            pwm_out => pwm_signal
        );

    led <= pwm_signal;

end Behavioral;
